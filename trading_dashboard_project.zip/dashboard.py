import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(layout="wide", page_title="Trading Dashboard", page_icon="📈")

st.title("📊 Trading Performance Dashboard")

# تحميل البيانات من Google Sheets أو ملف محلي (مؤقتًا نستخدم CSV محلي)
try:
    df = pd.read_csv("trade_log.csv")
except FileNotFoundError:
    st.warning("⚠️ لم يتم العثور على ملف trade_log.csv، يرجى رفعه في نفس مجلد التطبيق.")
    st.stop()

# معالجة البيانات
df["PnL (%)"] = ((df["exit_price"] - df["entry_price"]) / df["entry_price"]) * 100
df["timestamp"] = pd.to_datetime(df["timestamp"])

# إظهار الإحصائيات العامة
st.subheader("📈 نظرة عامة")
col1, col2, col3 = st.columns(3)
col1.metric("عدد الصفقات", len(df))
col2.metric("متوسط PnL", f"{df['PnL (%)'].mean():.2f}%")
col3.metric("نسبة النجاح", f"{(df['PnL (%)'] > 0).mean() * 100:.2f}%")

# رسم بياني لأداء الصفقات بمرور الوقت
st.subheader("📅 الأداء عبر الوقت")
fig = px.line(df, x="timestamp", y="PnL (%)", title="Performance Over Time", markers=True)
st.plotly_chart(fig, use_container_width=True)

# جدول الصفقات
st.subheader("📋 سجل الصفقات الكامل")
st.dataframe(df)